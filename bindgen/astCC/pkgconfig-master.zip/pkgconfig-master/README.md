## pkgconfig [![GoDoc](https://godoc.org/github.com/xlab/pkgconfig/pkg?status.svg)](https://godoc.org/github.com/xlab/pkgconfig/pkg)

A lightweight [pkg-config(1)](http://linux.die.net/man/1/pkg-config) clone written in Go. Currently supports only a limited set of features and WIP.

Don't use this stuff yet.
