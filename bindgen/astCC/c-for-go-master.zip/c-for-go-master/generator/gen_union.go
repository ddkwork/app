package generator

import "io"

func (gen *Generator) WriteUnions(wr io.Writer) int {
	return 0
}
